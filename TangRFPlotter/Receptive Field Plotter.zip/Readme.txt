To run the script do the following:

1) Make sure python 3.7 is installed, NOT 3.8
		Certain functions are not compatible with python 3.
2) Make sure MATLAB has the same number of bits as python, i.e both 32 bit architecture or 64.
3) Install pip if it has not been installed already
		To check if pip is installed, run "pip -V" in the shell
4) Use pip to install the following
		1) Numpy
		2) Scipy
5) Install the MATLAB Entine API for Python by following the following URL
		https://uk.mathworks.com/help/matlab/matlab_external/install-the-matlab-engine-for-python.html